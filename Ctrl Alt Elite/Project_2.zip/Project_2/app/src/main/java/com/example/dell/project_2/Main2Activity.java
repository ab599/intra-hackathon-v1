package com.example.dell.project_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void buttonclicked1(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked2(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked3(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked4(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked5(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked6(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    public void buttonclicked7(View v1) {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }
}