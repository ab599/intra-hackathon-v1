package com.example.dell.project_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.dell.project_2.Main2Activity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void buttonclicked(View v) {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }
    public void buttonclicked10(View v) {
        Intent intent = new Intent(this, Main4Activity.class);
        startActivity(intent);
    }

    public void buttonclicked11(View v) {
        Intent intent = new Intent(this, Main5Activity.class);
        startActivity(intent);
    }
    public void buttonclicked12(View v) {
        Intent intent = new Intent(this, Main6Activity.class);
        startActivity(intent);
    }


}